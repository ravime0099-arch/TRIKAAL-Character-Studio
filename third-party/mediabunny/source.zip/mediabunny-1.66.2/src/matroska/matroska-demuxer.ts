/*!
 * Copyright (c) 2026-present, Vanilagy and contributors
 *
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */

import { TrackType } from '../output';
import {
	determineAudioPacketType,
	extractAv1CodecInfoFromPacket,
	extractDtsFourCcFromPacket,
	extractAvcDecoderConfigurationRecord,
	extractHevcDecoderConfigurationRecord,
	extractProresCodecInfoFromPacket,
	extractVp9CodecInfoFromPacket,
} from '../codec-data';
import {
	AacCodecInfo,
	AUDIO_CODECS_WITH_DELTA_PACKETS,
	AudioCodec,
	DtsFourCc,
	extractAudioCodecString,
	extractColorSpace,
	extractVideoCodecString,
	MediaCodec,
	OPUS_SAMPLE_RATE,
	PRORES_FOURCCS,
	ProresFourCc,
	VideoCodec,
} from '../codec';
import { Demuxer } from '../demuxer';
import { Input } from '../input';
import { Logging } from '../logging';
import {
	InputAudioTrackBacking,
	InputTrackBacking,
	InputVideoTrackBacking,
} from '../input-track';
import { AttachedFile, DEFAULT_TRACK_DISPOSITION, MetadataTags, TrackDisposition } from '../metadata';
import { PacketRetrievalOptions } from '../media-sink';
import {
	assert,
	binarySearchLessOrEqual,
	COLOR_PRIMARIES_MAP_INVERSE,
	colorSpaceIsComplete,
	EMPTY_COLOR_SPACE,
	findLastIndex,
	isIso639Dash2LanguageCode,
	isThenable,
	last,
	MATRIX_COEFFICIENTS_MAP_INVERSE,
	centeredTransformationMatrix,
	DEG_TO_RAD,
	multiplyMatrices,
	normalizeRotation,
	Rotation,
	rotationMatrix,
	roundIfAlmostInteger,
	scaleMatrix,
	textDecoder,
	toDataView,
	TRANSFER_CHARACTERISTICS_MAP_INVERSE,
	UNDETERMINED_LANGUAGE,
	parseIsoSuffix,
} from '../misc';
import { EncodedPacket, EncodedPacketSideData, PLACEHOLDER_DATA } from '../packet';
import {
	assertDefinedSize,
	CODEC_STRING_MAP,
	EBMLId,
	LEVEL_0_AND_1_EBML_IDS,
	LEVEL_0_EBML_IDS,
	LEVEL_1_EBML_IDS,
	MAX_HEADER_SIZE,
	MIN_HEADER_SIZE,
	readAsciiString,
	readUnicodeString,
	readElementHeader,
	readFloat,
	readUnsignedInt,
	readVarInt,
	resync,
	searchForNextElementId,
	readUnsignedBigInt,
	readSignedBigInt,
	EBML_DATE_EPOCH,
} from './ebml';
import { buildMatroskaMimeType } from './matroska-misc';
import { buildAacAudioSpecificConfig } from '../../shared/aac-misc';
import { FileSlice, readBytes, Reader, readI16Be, readU8 } from '../reader';

type Segment = {
	seekHeadSeen: boolean;
	infoSeen: boolean;
	tracksSeen: boolean;
	cuesSeen: boolean;
	attachmentsSeen: boolean;
	tagsSeen: boolean;

	timestampScale: number;
	timestampFactor: number;
	duration: number;
	seekEntries: SeekEntry[];
	tracks: InternalTrack[];
	idToTrack: Map<number, InternalTrack>;
	cuePoints: CuePoint[];

	dataStartPos: number;
	elementEndPos: number | null;
	clusterSeekStartPos: number;

	/**
	 * Caches the last cluster that was read. Based on the assumption that there will be multiple reads to the
	 * same cluster in quick succession.
	 */
	lastReadCluster: Cluster | null;
	clusterSummaries: Map<number, ClusterSummary>; // Keyed by cluster position

	metadataTags: MetadataTags;
	metadataTagsPromise: Promise<void> | null;
};

type SeekEntry = {
	id: number;
	segmentPosition: number;
};

type Cluster = {
	segment: Segment;
	elementStartPos: number;
	elementEndPos: number;
	dataStartPos: number;
	timestamp: number;
	trackData: Map<number, ClusterTrackData>;
};

type ClusterSummary = {
	elementEndPos: number;
	trackIds: Set<number>; // The tracks with blocks in the cluster
};

type ClusterTrackData = {
	track: InternalTrack;
	startTimestamp: number;
	endTimestamp: number;
	firstKeyFrameTimestamp: number | null;
	blocks: ClusterBlock[];
	presentationTimestamps: {
		timestamp: number;
		blockIndex: number;
	}[];
};

enum BlockLacing {
	None,
	Xiph,
	FixedSize,
	Ebml,
}

type ClusterBlock = {
	timestamp: number;
	duration: number;
	isKeyFrame: boolean;
	data: Uint8Array;
	lacing: BlockLacing;
	decoded: boolean;
	postProcessed: boolean; // For codec-specific processing
	mainAdditional: Uint8Array | null;
};

type CuePoint = {
	time: number;
	trackId: number;
	clusterPosition: number;
};

enum ContentEncodingScope {
	Block = 1,
	Private = 2,
	Next = 4,
}

enum ContentCompAlgo {
	Zlib,
	Bzlib,
	lzo1x,
	HeaderStripping,
}

type DecodingInstruction = {
	order: number;
	scope: ContentEncodingScope;
	data: {
		type: 'decompress';
		algorithm: ContentCompAlgo | null;
		settings: Uint8Array | null;
	} | {
		type: 'decrypt';
		// Don't store more yet since this operation is unsupported
	} | null;
};

type InternalTrack = {
	id: number;
	demuxer: MatroskaDemuxer;
	segment: Segment;
	/**
	 * List of all encountered cluster offsets alongside their timestamps. This list never gets truncated, but memory
	 * consumption should be negligible.
	 */
	clusterPositionCache: {
		elementStartPos: number;
		startTimestamp: number;
		hasKeyFrame: boolean;
	}[];
	cuePoints: CuePoint[];

	disposition: TrackDisposition;
	trackBacking: InputTrackBacking | null;
	codecId: string | null;
	codecPrivate: Uint8Array | null;
	defaultDuration: number | null;
	defaultDurationNs: number | null;
	codecDelay: number;
	codecDelayNs: number;
	name: string | null;
	languageCode: string;
	hasLanguageBcp47: boolean;
	decodingInstructions: DecodingInstruction[];

	info:
		| null
		| {
			type: 'video';
			width: number;
			height: number;
			displayWidth: number | null;
			displayHeight: number | null;
			displayUnit: number;
			stereoMode: number;
			squarePixelWidth: number;
			squarePixelHeight: number;
			horizontalScale: number;
			verticalScale: number;
			rotation: Rotation;
			codec: VideoCodec | null;
			codecDescription: Uint8Array | null;
			colorSpace: VideoColorSpaceInit;
			alphaMode: boolean;
			proresFormat: ProresFourCc | null;
		}
		| {
			type: 'audio';
			numberOfChannels: number;
			sampleRate: number;
			outputSampleRate: number | null;
			bitDepth: number;
			codec: AudioCodec | null;
			codecDescription: Uint8Array | null;
			aacCodecInfo: AacCodecInfo | null;
			dtsFormat: DtsFourCc | null;
		};
};
type InternalVideoTrack = InternalTrack & { info: { type: 'video' } };
type InternalAudioTrack = InternalTrack & { info: { type: 'audio' } };

const METADATA_ELEMENTS = [
	{ id: EBMLId.SeekHead, flag: 'seekHeadSeen' },
	{ id: EBMLId.Info, flag: 'infoSeen' },
	{ id: EBMLId.Tracks, flag: 'tracksSeen' },
	{ id: EBMLId.Cues, flag: 'cuesSeen' },
] as const;
const MAX_RESYNC_LENGTH = 10 * 2 ** 20; // 10 MiB
const MAX_ELEMENT_NESTING_DEPTH = 64;

export class MatroskaDemuxer extends Demuxer {
	reader: Reader;

	readMetadataPromise: Promise<void> | null = null;

	segments: Segment[] = [];
	currentSegment: Segment | null = null;
	currentTrack: InternalTrack | null = null;
	currentCluster: Cluster | null = null;
	currentBlock: ClusterBlock | null = null;
	currentBlockAdditional: {
		addId: number;
		data: Uint8Array | null;
	} | null = null;

	currentCueTime: number | null = null;
	currentDecodingInstruction: DecodingInstruction | null = null;
	currentProjection: {
		type: number;
		yaw: number;
		pitch: number;
		roll: number;
	} | null = null;

	currentTagTargetIsMovie: boolean = true;
	currentSimpleTagName: string | null = null;
	currentAttachedFile: {
		fileUid: bigint | null;
		fileName: string | null;
		fileMediaType: string | null;
		fileData: Uint8Array | null;
		fileDescription: string | null;
	} | null = null;

	isWebM = false;
	claimedSeekTargets = new Set<number>();
	elementNestingDepth = 0;

	constructor(input: Input) {
		super(input);

		this.reader = input._reader;
	}

	async getTrackBackings() {
		await this.readMetadata();
		return this.segments.flatMap(segment => segment.tracks.map(track => track.trackBacking!));
	}

	override async getMimeType() {
		await this.readMetadata();

		const backings = await this.getTrackBackings();
		const codecStrings = await Promise.all(backings.map(
			x => x.getDecoderConfig().then(c => c?.codec ?? null),
		));

		return buildMatroskaMimeType({
			isWebM: this.isWebM,
			hasVideo: this.segments.some(segment => segment.tracks.some(x => x.info?.type === 'video')),
			hasAudio: this.segments.some(segment => segment.tracks.some(x => x.info?.type === 'audio')),
			codecStrings: codecStrings.filter(Boolean) as string[],
		});
	}

	async getMetadataTags() {
		await this.readMetadata();

		// Load metadata tags from each segment lazily (only once)
		for (const segment of this.segments) {
			if (!segment.metadataTagsPromise) {
				if (this.reader.fileSize !== null) {
					segment.metadataTagsPromise = this.loadSegmentMetadata(segment);
				} else {
					// The seeking would be too crazy, let's not
					segment.metadataTagsPromise = Promise.resolve();
				}
			}

			await segment.metadataTagsPromise;
		}

		// This is kinda handwavy, and how we handle multiple segments isn't suuuuper well-defined anyway; so we just
		// shallow-merge metadata tags from all (usually just one) segments.
		let metadataTags: MetadataTags = {};
		for (const segment of this.segments) {
			metadataTags = { ...metadataTags, ...segment.metadataTags };
		}

		return metadataTags;
	}

	readMetadata() {
		return this.readMetadataPromise ??= (async () => {
			let currentPos = 0;

			// Loop over all top-level elements in the file
			while (true) {
				let slice = this.reader.requestSliceRange(currentPos, MIN_HEADER_SIZE, MAX_HEADER_SIZE);
				if (isThenable(slice)) slice = await slice;
				if (!slice) break;

				const header = readElementHeader(slice);
				if (!header) {
					break; // Zero padding at the end of the file triggers this, for example
				}

				const id = header.id;
				let size = header.size;
				const dataStartPos = slice.filePos;

				if (id === EBMLId.EBML) {
					assertDefinedSize(size);

					let slice = this.reader.requestSlice(dataStartPos, size);
					if (isThenable(slice)) slice = await slice;
					if (!slice) break;

					this.readContiguousElements(slice);
				} else if (id === EBMLId.Segment) { // Segment found!
					await this.readSegment(dataStartPos, size);

					if (size === undefined) {
						// Segment sizes can be undefined (common in livestreamed files), so assume this is the last
						// and only segment
						break;
					}

					if (this.reader.fileSize === null) {
						break; // Stop at the first segment
					}
				} else if (id === EBMLId.Cluster) {
					if (this.reader.fileSize === null) {
						break; // Shouldn't be reached anyway, since we stop at the first segment
					}

					// Clusters are not a top-level element in Matroska, but some files contain a Segment whose size
					// doesn't contain any of the clusters that follow it. In the case, we apply the following logic: if
					// we find a top-level cluster, attribute it to the previous segment.

					if (size === undefined) {
						// Just in case this is one of those weird sizeless clusters, let's do our best and still try to
						// determine its size.
						const nextElementPos = await searchForNextElementId(
							this.reader,
							dataStartPos,
							LEVEL_0_AND_1_EBML_IDS,
							this.reader.fileSize,
						);
						size = nextElementPos.pos - dataStartPos;
					}

					const lastSegment = last(this.segments);
					if (lastSegment) {
						// Extend the previous segment's size
						lastSegment.elementEndPos = dataStartPos + size;
					}
				}

				assertDefinedSize(size);
				currentPos = dataStartPos + size;
			}
		})();
	}

	async readSegment(segmentDataStart: number, dataSize: number | undefined) {
		this.currentSegment = {
			seekHeadSeen: false,
			infoSeen: false,
			tracksSeen: false,
			cuesSeen: false,
			tagsSeen: false,
			attachmentsSeen: false,

			timestampScale: -1,
			timestampFactor: -1,
			duration: -1,
			seekEntries: [],
			tracks: [],
			idToTrack: new Map(),
			cuePoints: [],

			dataStartPos: segmentDataStart,
			elementEndPos: dataSize === undefined
				? null // Assume it goes until the end of the file
				: segmentDataStart + dataSize,
			clusterSeekStartPos: segmentDataStart,

			lastReadCluster: null,
			clusterSummaries: new Map(),

			metadataTags: {},
			metadataTagsPromise: null,
		};
		this.segments.push(this.currentSegment);

		let currentPos = segmentDataStart;
		const visitedSeekHeadPositions = new Set<number>();

		while (this.currentSegment.elementEndPos === null || currentPos < this.currentSegment.elementEndPos) {
			let slice = this.reader.requestSliceRange(currentPos, MIN_HEADER_SIZE, MAX_HEADER_SIZE);
			if (isThenable(slice)) slice = await slice;
			if (!slice) break;

			const elementStartPos = currentPos;
			const header = readElementHeader(slice);

			if (!header || (!LEVEL_1_EBML_IDS.includes(header.id) && header.id !== EBMLId.Void)) {
				// Potential junk. Let's try to resync (skipping the current position, which might hold a valid ID
				// followed by a broken size)

				const nextPos = await resync(
					this.reader,
					elementStartPos + 1,
					LEVEL_1_EBML_IDS,
					Math.min(this.currentSegment.elementEndPos ?? Infinity, elementStartPos + MAX_RESYNC_LENGTH),
				);

				if (nextPos) {
					currentPos = nextPos;
					continue;
				} else {
					break; // Resync failed
				}
			}

			const { id, size } = header;
			const dataStartPos = slice.filePos;

			const metadataElementIndex = METADATA_ELEMENTS.findIndex(x => x.id === id);
			if (metadataElementIndex !== -1) {
				const field = METADATA_ELEMENTS[metadataElementIndex]!.flag;
				this.currentSegment[field] = true;

				if (id === EBMLId.SeekHead) {
					visitedSeekHeadPositions.add(elementStartPos - segmentDataStart);
				}

				assertDefinedSize(size);

				let slice = this.reader.requestSlice(dataStartPos, size);
				if (isThenable(slice)) slice = await slice;

				if (slice) {
					this.readContiguousElements(slice);
				}
			} else if (id === EBMLId.Tags || id === EBMLId.Attachments) {
				// Metadata found at the beginning of the segment, great, let's parse it
				if (id === EBMLId.Tags) {
					this.currentSegment.tagsSeen = true;
				} else {
					this.currentSegment.attachmentsSeen = true;
				}

				assertDefinedSize(size);

				let slice = this.reader.requestSlice(dataStartPos, size);
				if (isThenable(slice)) slice = await slice;

				if (slice) {
					this.readContiguousElements(slice);
				}
			} else if (id === EBMLId.Cluster) {
				this.currentSegment.clusterSeekStartPos = elementStartPos;
				break; // Stop at the first cluster
			}

			if (size === undefined) {
				break;
			} else {
				currentPos = dataStartPos + size;
			}
		}

		if (this.reader.fileSize !== null) {
			// Seek heads can sometimes point to other seek heads, so follow them until there are no unvisited
			// ones left. Following a seek head appends its entries to the list we're iterating over.
			for (let i = 0; i < this.currentSegment.seekEntries.length; i++) {
				const seekEntry = this.currentSegment.seekEntries[i]!;
				if (seekEntry.id !== EBMLId.SeekHead || visitedSeekHeadPositions.has(seekEntry.segmentPosition)) {
					continue;
				}

				visitedSeekHeadPositions.add(seekEntry.segmentPosition);
				if (!this.claimSeekTarget(segmentDataStart + seekEntry.segmentPosition)) {
					continue;
				}

				let slice = this.reader.requestSliceRange(
					segmentDataStart + seekEntry.segmentPosition,
					MIN_HEADER_SIZE,
					MAX_HEADER_SIZE,
				);
				if (isThenable(slice)) slice = await slice;
				if (!slice) continue;

				const header = readElementHeader(slice);
				if (!header || header.id !== EBMLId.SeekHead) continue;

				const { size } = header;
				assertDefinedSize(size);

				let dataSlice = this.reader.requestSlice(slice.filePos, size);
				if (isThenable(dataSlice)) dataSlice = await dataSlice;
				if (!dataSlice) continue;

				this.readContiguousElements(dataSlice);
			}
		}

		// Sort the seek entries by file position so reading them exhibits a sequential pattern
		this.currentSegment.seekEntries.sort((a, b) => a.segmentPosition - b.segmentPosition);

		if (this.reader.fileSize !== null) {
			// Use the seek head to read missing metadata elements
			for (const seekEntry of this.currentSegment.seekEntries) {
				const target = METADATA_ELEMENTS.find(x => x.id === seekEntry.id);
				if (!target) {
					continue;
				}

				if (this.currentSegment[target.flag]) continue;
				if (!this.claimSeekTarget(segmentDataStart + seekEntry.segmentPosition)) continue;

				let slice = this.reader.requestSliceRange(
					segmentDataStart + seekEntry.segmentPosition,
					MIN_HEADER_SIZE,
					MAX_HEADER_SIZE,
				);
				if (isThenable(slice)) slice = await slice;
				if (!slice) continue;

				const header = readElementHeader(slice);
				if (!header) continue;

				const { id, size } = header;
				if (id !== target.id) continue;

				assertDefinedSize(size);

				this.currentSegment[target.flag] = true;

				let dataSlice = this.reader.requestSlice(slice.filePos, size);
				if (isThenable(dataSlice)) dataSlice = await dataSlice;
				if (!dataSlice) continue;

				this.readContiguousElements(dataSlice);
			}
		}

		if (this.currentSegment.timestampScale === -1) {
			// TimestampScale element is missing. Technically an invalid file, but let's default to the typical value,
			// which is 1e6.
			this.currentSegment.timestampScale = 1e6;
			this.currentSegment.timestampFactor = 1e9 / 1e6;
		}

		// Compute default duration and codec delay for all tracks now that we have the timestamp factor
		for (const track of this.currentSegment.tracks) {
			if (track.defaultDurationNs !== null) {
				track.defaultDuration = (this.currentSegment.timestampFactor * track.defaultDurationNs) / 1e9;
			}

			track.codecDelay = Math.round((this.currentSegment.timestampFactor * track.codecDelayNs) / 1e9);
		}

		// Assign cue points to their respective tracks
		for (const cuePoint of this.currentSegment.cuePoints) {
			const track = this.currentSegment.idToTrack.get(cuePoint.trackId);
			if (track) {
				track.cuePoints.push(cuePoint);
			}
		}

		for (const track of this.currentSegment.tracks) {
			// Sort cue points by time and remove multiple cue points for the same time
			const cuePoints = track.cuePoints;
			cuePoints.sort((a, b) => a.time - b.time);

			let writeIndex = 0;
			for (const cuePoint of cuePoints) {
				if (writeIndex === 0 || cuePoint.time !== cuePoints[writeIndex - 1]!.time) {
					cuePoints[writeIndex++] = cuePoint;
				}
			}
			cuePoints.length = writeIndex;
		}

		let trackWithMostCuePoints: InternalTrack | null = null;
		let maxCuePointCount = -Infinity;
		for (const track of this.currentSegment.tracks) {
			if (track.cuePoints.length > maxCuePointCount) {
				maxCuePointCount = track.cuePoints.length;
				trackWithMostCuePoints = track;
			}
		}

		// For every track that has received 0 cue points (can happen, often only the video track receives cue points),
		// we still want to have better seeking. Therefore, let's give it the cue points of the track with the most cue
		// points, which should provide us with the most fine-grained seeking.
		for (const track of this.currentSegment.tracks) {
			if (track.cuePoints.length === 0) {
				track.cuePoints = trackWithMostCuePoints!.cuePoints;
			}
		}

		this.currentSegment = null;
	}

	async readCluster(startPos: number, segment: Segment) {
		if (segment.lastReadCluster?.elementStartPos === startPos) {
			return segment.lastReadCluster;
		}

		let headerSlice = this.reader.requestSliceRange(startPos, MIN_HEADER_SIZE, MAX_HEADER_SIZE);
		if (isThenable(headerSlice)) headerSlice = await headerSlice;
		assert(headerSlice);

		const elementStartPos = startPos;
		const elementHeader = readElementHeader(headerSlice);
		assert(elementHeader);

		const id = elementHeader.id;
		assert(id === EBMLId.Cluster);

		let size = elementHeader.size;
		const dataStartPos = headerSlice.filePos;

		if (size === undefined) {
			// The cluster's size is undefined (can happen in livestreamed files). We'd still like to know the size of
			// it, so we have no other choice but to iterate over the EBML structure until we find an element at level
			// 0 or 1, indicating the end of the cluster (all elements inside the cluster are at level 2).
			const nextElementPos = await searchForNextElementId(
				this.reader,
				dataStartPos,
				LEVEL_0_AND_1_EBML_IDS,
				segment.elementEndPos,
			);

			size = nextElementPos.pos - dataStartPos;
		}

		// Load the entire cluster, or whatever's left of it in case the file got cut off
		let dataSlice = this.reader.requestSliceRange(dataStartPos, 0, size);
		if (isThenable(dataSlice)) dataSlice = await dataSlice;

		const cluster: Cluster = {
			segment,
			elementStartPos,
			elementEndPos: dataStartPos + size,
			dataStartPos,
			timestamp: -1,
			trackData: new Map(),
		};
		if (dataSlice) {
			this.currentCluster = cluster;

			try {
				// Read the children of the cluster, stopping early at level 0 or 1 EBML elements. We do this because
				// some clusters have incorrect sizes that are too large
				const endPos = this.readContiguousElements(dataSlice, LEVEL_0_AND_1_EBML_IDS);
				cluster.elementEndPos = endPos;
			} finally {
				this.currentCluster = null;
				this.currentBlock = null;
			}
		}

		for (const [, trackData] of cluster.trackData) {
			const track = trackData.track;

			// This must hold, as track datas only get created if a block for that track is encountered
			assert(trackData.blocks.length > 0);

			let hasLacedBlocks = false;

			for (let i = 0; i < trackData.blocks.length; i++) {
				const block = trackData.blocks[i]!;
				block.timestamp += cluster.timestamp;

				hasLacedBlocks ||= block.lacing !== BlockLacing.None;
			}

			trackData.presentationTimestamps = trackData.blocks
				.map((block, i) => ({ timestamp: block.timestamp, blockIndex: i }))
				.sort((a, b) => a.timestamp - b.timestamp);

			for (let i = 0; i < trackData.presentationTimestamps.length; i++) {
				const currentEntry = trackData.presentationTimestamps[i]!;
				const currentBlock = trackData.blocks[currentEntry.blockIndex]!;

				if (i < trackData.presentationTimestamps.length - 1) {
					// Update block durations based on presentation order
					const nextEntry = trackData.presentationTimestamps[i + 1]!;
					currentBlock.duration = nextEntry.timestamp - currentBlock.timestamp;
				} else if (currentBlock.duration === 0) {
					if (track.defaultDuration != null) {
						if (currentBlock.lacing === BlockLacing.None) {
							currentBlock.duration = Math.round(track.defaultDuration);
						} else {
							// Handled by the lace resolution code
						}
					}
				}
			}

			if (hasLacedBlocks) {
				// Perform lace resolution. Here, we expand each laced block into multiple blocks where each contains
				// one frame of the lace. We do this after determining block timestamps so we can properly distribute
				// the block's duration across the laced frames.
				trackData.blocks = this.expandLacedBlocks(trackData.blocks, track);

				// Recompute since blocks have changed
				trackData.presentationTimestamps = trackData.blocks
					.map((block, i) => ({ timestamp: block.timestamp, blockIndex: i }))
					.sort((a, b) => a.timestamp - b.timestamp);
			}

			if (track.info?.type === 'audio' && track.info.codec) {
				// The container's key flags can't be trusted for audio: some files don't mark their packets as key
				// packets (I'm looking at you, Firefox, https://github.com/Vanilagy/mediabunny/issues/192), and laced
				// frames all inherit their block's flag. So the frames decide themselves (unless they still need to
				// be decoded).
				const hasDeltaPackets = AUDIO_CODECS_WITH_DELTA_PACKETS.includes(track.info.codec);
				for (const block of trackData.blocks) {
					if (block.decoded || !hasDeltaPackets) {
						block.isKeyFrame = determineAudioPacketType(track.info.codec, block.data) === 'key';
					}
				}
			}

			const firstKeyEntry = trackData.presentationTimestamps
				.find(x => trackData.blocks[x.blockIndex]!.isKeyFrame);
			if (firstKeyEntry) {
				trackData.firstKeyFrameTimestamp = firstKeyEntry.timestamp;
			}

			const firstBlock = trackData.blocks[trackData.presentationTimestamps[0]!.blockIndex]!;
			const lastBlock = trackData.blocks[last(trackData.presentationTimestamps)!.blockIndex]!;

			trackData.startTimestamp = firstBlock.timestamp;
			trackData.endTimestamp = lastBlock.timestamp + lastBlock.duration;

			// Let's remember that a cluster with a given timestamp is here, speeding up future lookups if no cues exist
			const insertionIndex = binarySearchLessOrEqual(
				track.clusterPositionCache,
				trackData.startTimestamp,
				x => x.startTimestamp,
			);
			const previousEntry = track.clusterPositionCache[insertionIndex];
			const nextEntry = track.clusterPositionCache[insertionIndex + 1];

			// Only remember it if the timestamp order matches the cluster position order
			if (
				(!previousEntry || previousEntry.elementStartPos < elementStartPos)
				&& (!nextEntry || nextEntry.elementStartPos > elementStartPos)
			) {
				track.clusterPositionCache.splice(insertionIndex + 1, 0, {
					elementStartPos: cluster.elementStartPos,
					startTimestamp: trackData.startTimestamp,
					hasKeyFrame: trackData.firstKeyFrameTimestamp !== null,
				});
			}
		}

		segment.lastReadCluster = cluster;
		segment.clusterSummaries.set(startPos, {
			elementEndPos: cluster.elementEndPos,
			trackIds: new Set(cluster.trackData.keys()),
		});

		return cluster;
	}

	getTrackDataInCluster(cluster: Cluster, trackNumber: number) {
		let trackData = cluster.trackData.get(trackNumber);
		if (!trackData) {
			const track = cluster.segment.idToTrack.get(trackNumber);
			if (!track) {
				return null;
			}

			trackData = {
				track,
				startTimestamp: 0,
				endTimestamp: 0,
				firstKeyFrameTimestamp: null,
				blocks: [],
				presentationTimestamps: [],
			};
			cluster.trackData.set(trackNumber, trackData);
		}

		return trackData;
	}

	expandLacedBlocks(blocks: ClusterBlock[], track: InternalTrack) {
		// https://www.matroska.org/technical/notes.html#block-lacing

		const expandedBlocks: ClusterBlock[] = [];

		for (const originalBlock of blocks) {
			if (originalBlock.lacing === BlockLacing.None) {
				expandedBlocks.push(originalBlock);
				continue;
			}

			// Content encodings apply to each frame, excluding the lacing data, so the frames get decoded lazily later
			const slice = FileSlice.tempFromBytes(originalBlock.data);
			if (slice.length === 0) {
				throw new Error('Invalid laced block: no data.');
			}

			const frameSizes: number[] = [];
			const frameCount = readU8(slice) + 1;

			switch (originalBlock.lacing) {
				case BlockLacing.Xiph: {
					let totalUsedSize = 0;

					// Xiph lacing, just like in Ogg
					for (let i = 0; i < frameCount - 1; i++) {
						let frameSize = 0;

						while (slice.bufferPos < slice.length) {
							const value = readU8(slice);
							frameSize += value;

							if (value < 255) {
								frameSizes.push(frameSize);
								totalUsedSize += frameSize;

								break;
							}
						}
					}

					// Compute the last frame's size from whatever's left
					frameSizes.push(slice.length - (slice.bufferPos + totalUsedSize));
				}; break;

				case BlockLacing.FixedSize: {
					// Fixed size lacing: all frames have same size
					const totalDataSize = slice.length - 1; // Minus the frame count byte
					const frameSize = Math.floor(totalDataSize / frameCount);

					for (let i = 0; i < frameCount; i++) {
						frameSizes.push(frameSize);
					}
				}; break;

				case BlockLacing.Ebml: {
					if (frameCount === 1) {
						// The only frame is also the last one, whose size is never coded
						frameSizes.push(slice.length - slice.bufferPos);
						break;
					}

					// EBML lacing: first size absolute, subsequent ones are coded as signed differences from the last
					const firstResult = readVarInt(slice);
					if (firstResult === null) {
						throw new Error('Invalid EBML lacing: bad frame size.');
					}

					let currentSize = firstResult;
					frameSizes.push(currentSize);

					let totalUsedSize = currentSize;

					for (let i = 1; i < frameCount - 1; i++) {
						const startPos = slice.bufferPos;
						const diffResult = readVarInt(slice);
						if (diffResult === null) {
							throw new Error('Invalid EBML lacing: bad frame size.');
						}

						const unsignedDiff = diffResult;
						const width = slice.bufferPos - startPos;
						const bias = (1 << (width * 7 - 1)) - 1; // Typo-corrected version of 2^((7*n)-1)^-1
						const diff = unsignedDiff - bias;

						currentSize += diff;
						frameSizes.push(currentSize);

						totalUsedSize += currentSize;
					}

					// Compute the last frame's size from whatever's left
					frameSizes.push(slice.length - (slice.bufferPos + totalUsedSize));
				}; break;

				default: assert(false);
			}

			// Every frame must hold actual data; this also catches frame sizes that exceed the block
			if (frameSizes.length !== frameCount || frameSizes.some(x => x <= 0)) {
				throw new Error('Invalid block lacing: frame sizes don\'t match the block.');
			}

			const blockDuration = originalBlock.duration || Math.round(frameCount * (track.defaultDuration ?? 0));

			// Now, let's replace the block with one block per frame
			for (let i = 0; i < frameCount; i++) {
				const frameSize = frameSizes[i]!;
				const frameData = readBytes(slice, frameSize);

				// Distribute timestamps evenly across the block duration while staying on the tick grid
				const frameStart = Math.floor(blockDuration * i / frameCount);
				const frameEnd = Math.floor(blockDuration * (i + 1) / frameCount);

				expandedBlocks.push({
					timestamp: originalBlock.timestamp + frameStart,
					duration: frameEnd - frameStart,
					isKeyFrame: originalBlock.isKeyFrame,
					data: frameData,
					lacing: BlockLacing.None,
					decoded: originalBlock.decoded,
					postProcessed: false,
					mainAdditional: originalBlock.mainAdditional,
				});
			}
		}

		return expandedBlocks;
	}

	async loadSegmentMetadata(segment: Segment) {
		for (const seekEntry of segment.seekEntries) {
			if (seekEntry.id === EBMLId.Tags && !segment.tagsSeen) {
				// We need to load the tags
			} else if (seekEntry.id === EBMLId.Attachments && !segment.attachmentsSeen) {
				// We need to load the attachments
			} else {
				continue;
			}

			if (!this.claimSeekTarget(segment.dataStartPos + seekEntry.segmentPosition)) {
				continue;
			}

			let slice = this.reader.requestSliceRange(
				segment.dataStartPos + seekEntry.segmentPosition,
				MIN_HEADER_SIZE,
				MAX_HEADER_SIZE,
			);
			if (isThenable(slice)) slice = await slice;
			if (!slice) continue;

			const header = readElementHeader(slice);
			if (!header || header.id !== seekEntry.id) continue;

			const { size } = header;
			assertDefinedSize(size);

			let dataSlice = this.reader.requestSlice(slice.filePos, size);
			if (isThenable(dataSlice)) dataSlice = await dataSlice;
			if (dataSlice) {
				// No awaiting while the segment is set, so concurrent calls can't interfere with each other
				assert(!this.currentSegment);
				this.currentSegment = segment;

				try {
					this.readContiguousElements(dataSlice);
				} finally {
					this.currentSegment = null;
				}
			}

			// Mark as seen
			if (seekEntry.id === EBMLId.Tags) {
				segment.tagsSeen = true;
			} else if (seekEntry.id === EBMLId.Attachments) {
				segment.attachmentsSeen = true;
			}
		}
	}

	claimSeekTarget(position: number) {
		if (this.claimedSeekTargets.has(position)) {
			return false;
		}

		this.claimedSeekTargets.add(position);
		return true;
	}

	readContiguousElements(slice: FileSlice, stopIds?: number[]) {
		if (this.elementNestingDepth === MAX_ELEMENT_NESTING_DEPTH) {
			throw new Error('Invalid file: elements are nested too deeply.');
		}

		this.elementNestingDepth++;

		try {
			while (slice.remainingLength >= MIN_HEADER_SIZE) {
				const startPos = slice.filePos;
				const foundElement = this.traverseElement(slice, stopIds);

				if (!foundElement) {
					return startPos;
				}
			}

			return slice.filePos;
		} finally {
			this.elementNestingDepth--;
		}
	}

	traverseElement(slice: FileSlice, stopIds?: number[]): boolean {
		const header = readElementHeader(slice);
		if (!header) {
			return false;
		}

		if (stopIds && stopIds.includes(header.id)) {
			return false;
		}

		const { id, size } = header;
		const dataStartPos = slice.filePos;
		assertDefinedSize(size);

		if (dataStartPos + size > slice.end) {
			return false; // The element doesn't fit into its parent
		}

		switch (id) {
			case EBMLId.DocType: {
				this.isWebM = readAsciiString(slice, size) === 'webm';
			}; break;

			case EBMLId.Seek: {
				if (!this.currentSegment) break;
				const seekEntry: SeekEntry = { id: -1, segmentPosition: -1 };
				this.currentSegment.seekEntries.push(seekEntry);
				this.readContiguousElements(slice.slice(dataStartPos, size));

				if (seekEntry.id === -1 || seekEntry.segmentPosition === -1) {
					this.currentSegment.seekEntries.pop();
				}
			}; break;

			case EBMLId.SeekID: {
				const lastSeekEntry = this.currentSegment?.seekEntries[this.currentSegment.seekEntries.length - 1];
				if (!lastSeekEntry) break;

				lastSeekEntry.id = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.SeekPosition: {
				const lastSeekEntry = this.currentSegment?.seekEntries[this.currentSegment.seekEntries.length - 1];
				if (!lastSeekEntry) break;

				lastSeekEntry.segmentPosition = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.TimestampScale: {
				if (!this.currentSegment) break;

				// Empty elements take their default value
				const timestampScale = size === 0 ? 1e6 : readUnsignedInt(slice, size);
				if (timestampScale === 0) {
					throw new Error('Invalid TimestampScale element: must not be 0.');
				}

				this.currentSegment.timestampScale = timestampScale;
				this.currentSegment.timestampFactor = 1e9 / timestampScale;
			}; break;

			case EBMLId.Duration: {
				if (!this.currentSegment) break;

				this.currentSegment.duration = readFloat(slice, size);
			}; break;

			case EBMLId.DateUTC: {
				if (!this.currentSegment) break;

				const nanoseconds = readSignedBigInt(slice, size);
				this.currentSegment.metadataTags.creationTime = new Date(
					EBML_DATE_EPOCH + Number(nanoseconds / 1_000_000n),
				);
			}; break;

			case EBMLId.Title: {
				if (!this.currentSegment) break;

				this.currentSegment.metadataTags.title ??= readUnicodeString(slice, size);
			}; break;

			case EBMLId.TrackEntry: {
				if (!this.currentSegment) break;

				this.currentTrack = {
					id: -1,
					segment: this.currentSegment,
					demuxer: this,
					clusterPositionCache: [],
					cuePoints: [],

					disposition: {
						...DEFAULT_TRACK_DISPOSITION,
						primary: false,
					},
					trackBacking: null,
					codecId: null,
					codecPrivate: null,
					defaultDuration: null,
					defaultDurationNs: null,
					codecDelay: 0,
					codecDelayNs: 0,
					name: null,
					languageCode: 'eng', // The default in Matroska
					hasLanguageBcp47: false,
					decodingInstructions: [],

					info: null,
				};

				this.readContiguousElements(slice.slice(dataStartPos, size));

				// Check if track was disabled during parsing (e.g., by FlagEnabled being 0)
				if (!this.currentTrack) {
					break;
				}

				if (this.currentTrack.decodingInstructions.some((instruction) => {
					return instruction.data?.type !== 'decompress'
						|| instruction.scope !== ContentEncodingScope.Block
						|| instruction.data.algorithm !== ContentCompAlgo.HeaderStripping;
				})) {
					Logging._warn(`Track #${this.currentTrack.id} has an unsupported content encoding; dropping.`);
					this.currentTrack = null;
				}

				if (this.currentTrack && this.currentSegment.idToTrack.has(this.currentTrack.id)) {
					// Blocks can't tell the tracks apart
					Logging._warn(`Track #${this.currentTrack.id} is defined more than once; dropping.`);
					this.currentTrack = null;
				}

				if (
					this.currentTrack
					&& this.currentTrack.id !== -1
					&& this.currentTrack.codecId
					&& this.currentTrack.info
				) {
					const slashIndex = this.currentTrack.codecId.indexOf('/');
					const codecIdWithoutSuffix = slashIndex === -1
						? this.currentTrack.codecId
						: this.currentTrack.codecId.slice(0, slashIndex);

					if (
						this.currentTrack.info.type === 'video'
						&& this.currentTrack.info.width !== -1
						&& this.currentTrack.info.height !== -1
					) {
						this.currentTrack.info.squarePixelWidth = this.currentTrack.info.width;
						this.currentTrack.info.squarePixelHeight = this.currentTrack.info.height;

						let displayWidth = this.currentTrack.info.displayWidth;
						let displayHeight = this.currentTrack.info.displayHeight;

						// With two views packed into one frame, the display size is that of a single view instead.
						// See https://www.matroska.org/technical/notes.html#multi-planar-and-3d-videos
						const stereoMode = this.currentTrack.info.stereoMode;
						if (displayWidth !== null && [1, 8, 9, 11].includes(stereoMode)) {
							displayWidth *= 2; // Side by side or column interleaved
						}
						if (displayHeight !== null && [2, 3, 6, 7].includes(stereoMode)) {
							displayHeight *= 2; // Top-bottom or row interleaved
						}

						if (this.currentTrack.info.displayUnit === 0) {
							displayWidth ??= this.currentTrack.info.width;
							displayHeight ??= this.currentTrack.info.height;
						}

						if (
							this.currentTrack.info.displayUnit !== 4 // "unknown"
							&& displayWidth !== null
							&& displayHeight !== null
						) {
							const num = displayWidth * this.currentTrack.info.height;
							const den = displayHeight * this.currentTrack.info.width;

							if (num > 0 && den > 0) {
								if (num > den) {
									this.currentTrack.info.squarePixelWidth = Math.round(
										this.currentTrack.info.width * num / den,
									);
								} else {
									this.currentTrack.info.squarePixelHeight = Math.round(
										this.currentTrack.info.height * den / num,
									);
								}
							}
						}

						if (this.currentTrack.codecId === CODEC_STRING_MAP.avc) {
							this.currentTrack.info.codec = 'avc';
							this.currentTrack.info.codecDescription = this.currentTrack.codecPrivate;
						} else if (this.currentTrack.codecId === CODEC_STRING_MAP.hevc) {
							this.currentTrack.info.codec = 'hevc';
							this.currentTrack.info.codecDescription = this.currentTrack.codecPrivate;
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.vp8) {
							this.currentTrack.info.codec = 'vp8';
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.vp9) {
							this.currentTrack.info.codec = 'vp9';
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.av1) {
							this.currentTrack.info.codec = 'av1';
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.prores) {
							const format = this.currentTrack.codecPrivate
								? textDecoder.decode(this.currentTrack.codecPrivate)
								: '';

							if ((PRORES_FOURCCS as readonly string[]).includes(format)) {
								this.currentTrack.info.codec = 'prores';
								this.currentTrack.info.proresFormat = format as ProresFourCc;
							} else {
								// Either an invalid string or ProRes RAW, which we don't support yet (it's a
								// different codec).
							}
						}

						const videoTrack = this.currentTrack as InternalVideoTrack;
						this.currentTrack.trackBacking = new MatroskaVideoTrackBacking(videoTrack);
						this.currentSegment.tracks.push(this.currentTrack);
						this.currentSegment.idToTrack.set(this.currentTrack.id, this.currentTrack);
					} else if (this.currentTrack.info.type === 'audio') {
						if (this.currentTrack.info.outputSampleRate !== null) {
							this.currentTrack.info.sampleRate = this.currentTrack.info.outputSampleRate;
						}

						if (codecIdWithoutSuffix === CODEC_STRING_MAP.aac) {
							this.currentTrack.info.codec = 'aac';
							this.currentTrack.info.aacCodecInfo = {
								isMpeg2: this.currentTrack.codecId.includes('MPEG2'),
								objectType: null,
							};
							this.currentTrack.info.codecDescription = this.currentTrack.codecPrivate;

							if (
								!this.currentTrack.codecPrivate
								&& this.currentTrack.codecId !== CODEC_STRING_MAP.aac
							) {
								// Legacy codec IDs like A_AAC/MPEG4/LC/SBR name the profile instead of a CodecPrivate
								const profile = this.currentTrack.codecId.split('/')[2] ?? '';
								const objectType = ['MAIN', 'LC', 'SSR', 'LTP'].indexOf(profile) + 1;
								if (objectType === 0) {
									throw new Error(`Unknown Matroska AAC codec ID '${this.currentTrack.codecId}'.`);
								}

								const usesSbr = this.currentTrack.codecId.endsWith('/SBR');
								if (usesSbr && this.currentTrack.info.outputSampleRate === null) {
									this.currentTrack.info.sampleRate *= 2;
								}

								this.currentTrack.info.codecDescription = buildAacAudioSpecificConfig({
									objectType: usesSbr ? 5 : objectType,
									outputSampleRate: this.currentTrack.info.sampleRate,
									outputNumberOfChannels: this.currentTrack.info.numberOfChannels,
									programConfigElement: null,
								});
							}
						} else if (this.currentTrack.codecId === CODEC_STRING_MAP.mp3) {
							this.currentTrack.info.codec = 'mp3';
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.opus) {
							this.currentTrack.info.codec = 'opus';
							this.currentTrack.info.codecDescription = this.currentTrack.codecPrivate;
							this.currentTrack.info.sampleRate = OPUS_SAMPLE_RATE; // Always the same
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.vorbis) {
							this.currentTrack.info.codec = 'vorbis';
							this.currentTrack.info.codecDescription = this.currentTrack.codecPrivate;
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.flac) {
							this.currentTrack.info.codec = 'flac';
							this.currentTrack.info.codecDescription = this.currentTrack.codecPrivate;
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.ac3) {
							this.currentTrack.info.codec = 'ac3';
							this.currentTrack.info.codecDescription = this.currentTrack.codecPrivate;
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.eac3) {
							this.currentTrack.info.codec = 'eac3';
							this.currentTrack.info.codecDescription = this.currentTrack.codecPrivate;
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.dts) {
							this.currentTrack.info.codec = 'dts';

							if (this.currentTrack.codecId === 'A_DTS/EXPRESS') {
								this.currentTrack.info.dtsFormat = 'dtse';
							} else if (this.currentTrack.codecId === 'A_DTS/LOSSLESS') {
								this.currentTrack.info.dtsFormat = 'dtsl';
							}
						} else if (codecIdWithoutSuffix === CODEC_STRING_MAP.truehd) {
							this.currentTrack.info.codec = 'truehd';
						} else if (this.currentTrack.codecId === 'A_PCM/INT/LIT') {
							if (this.currentTrack.info.bitDepth === 8) {
								this.currentTrack.info.codec = 'pcm-u8';
							} else if (this.currentTrack.info.bitDepth === 16) {
								this.currentTrack.info.codec = 'pcm-s16';
							} else if (this.currentTrack.info.bitDepth === 24) {
								this.currentTrack.info.codec = 'pcm-s24';
							} else if (this.currentTrack.info.bitDepth === 32) {
								this.currentTrack.info.codec = 'pcm-s32';
							}
						} else if (this.currentTrack.codecId === 'A_PCM/INT/BIG') {
							if (this.currentTrack.info.bitDepth === 8) {
								this.currentTrack.info.codec = 'pcm-u8';
							} else if (this.currentTrack.info.bitDepth === 16) {
								this.currentTrack.info.codec = 'pcm-s16be';
							} else if (this.currentTrack.info.bitDepth === 24) {
								this.currentTrack.info.codec = 'pcm-s24be';
							} else if (this.currentTrack.info.bitDepth === 32) {
								this.currentTrack.info.codec = 'pcm-s32be';
							}
						} else if (this.currentTrack.codecId === 'A_PCM/FLOAT/IEEE') {
							if (this.currentTrack.info.bitDepth === 32) {
								this.currentTrack.info.codec = 'pcm-f32';
							} else if (this.currentTrack.info.bitDepth === 64) {
								this.currentTrack.info.codec = 'pcm-f64';
							}
						}

						const audioTrack = this.currentTrack as InternalAudioTrack;
						this.currentTrack.trackBacking = new MatroskaAudioTrackBacking(audioTrack);
						this.currentSegment.tracks.push(this.currentTrack);
						this.currentSegment.idToTrack.set(this.currentTrack.id, this.currentTrack);
					}
				}

				this.currentTrack = null;
			}; break;

			case EBMLId.TrackNumber: {
				if (!this.currentTrack) break;

				this.currentTrack.id = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.TrackType: {
				if (!this.currentTrack) break;

				const type = readUnsignedInt(slice, size);
				if (type === 1) {
					this.currentTrack.info = {
						type: 'video',
						width: -1,
						height: -1,
						displayWidth: null,
						displayHeight: null,
						displayUnit: 0, // Pixels
						stereoMode: 0, // Mono
						squarePixelWidth: -1,
						squarePixelHeight: -1,
						horizontalScale: 1,
						verticalScale: 1,
						rotation: 0,
						codec: null,
						codecDescription: null,
						colorSpace: { ...EMPTY_COLOR_SPACE },
						alphaMode: false,
						proresFormat: null,
					};
				} else if (type === 2) {
					this.currentTrack.info = {
						type: 'audio',
						numberOfChannels: 1, // Default value
						sampleRate: 8000, // Default value
						outputSampleRate: null,
						bitDepth: -1,
						codec: null,
						codecDescription: null,
						aacCodecInfo: null,
						dtsFormat: null,
					};
				}
			}; break;

			case EBMLId.FlagEnabled: {
				if (!this.currentTrack) break;

				const enabled = size === 0 ? 1 : readUnsignedInt(slice, size);
				if (!enabled) {
					this.currentTrack = null;
				}
			}; break;

			case EBMLId.FlagDefault: {
				if (!this.currentTrack) break;

				this.currentTrack.disposition.default = size === 0 || !!readUnsignedInt(slice, size);
			}; break;

			case EBMLId.FlagForced: {
				if (!this.currentTrack) break;

				this.currentTrack.disposition.forced = !!readUnsignedInt(slice, size);
			}; break;

			case EBMLId.FlagOriginal: {
				if (!this.currentTrack) break;

				this.currentTrack.disposition.original = !!readUnsignedInt(slice, size);
			}; break;

			case EBMLId.FlagHearingImpaired: {
				if (!this.currentTrack) break;

				this.currentTrack.disposition.hearingImpaired = !!readUnsignedInt(slice, size);
			}; break;

			case EBMLId.FlagVisualImpaired: {
				if (!this.currentTrack) break;

				this.currentTrack.disposition.visuallyImpaired = !!readUnsignedInt(slice, size);
			}; break;

			case EBMLId.FlagCommentary: {
				if (!this.currentTrack) break;

				this.currentTrack.disposition.commentary = !!readUnsignedInt(slice, size);
			}; break;

			case EBMLId.CodecID: {
				if (!this.currentTrack) break;

				this.currentTrack.codecId = readAsciiString(slice, size);
			}; break;

			case EBMLId.CodecPrivate: {
				if (!this.currentTrack) break;

				this.currentTrack.codecPrivate = readBytes(slice, size);
			}; break;

			case EBMLId.DefaultDuration: {
				if (!this.currentTrack) break;
				this.currentTrack.defaultDurationNs = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.CodecDelay: {
				if (!this.currentTrack) break;
				this.currentTrack.codecDelayNs = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.Name: {
				if (!this.currentTrack) break;

				this.currentTrack.name = readUnicodeString(slice, size);
			}; break;

			case EBMLId.Language: {
				if (!this.currentTrack) break;
				if (this.currentTrack.hasLanguageBcp47) {
					// LanguageBCP47 was present, which takes precedence
					break;
				}

				this.currentTrack.languageCode = size === 0 ? 'eng' : readAsciiString(slice, size);

				if (!isIso639Dash2LanguageCode(this.currentTrack.languageCode)) {
					this.currentTrack.languageCode = UNDETERMINED_LANGUAGE;
				}
			}; break;

			case EBMLId.LanguageBCP47: {
				if (!this.currentTrack) break;

				const bcp47 = readAsciiString(slice, size);
				const languageSubtag = bcp47.split('-')[0];

				if (languageSubtag) {
					// Technically invalid, for now: The language subtag might be a language code from ISO 639-1,
					// ISO 639-2, ISO 639-3, ISO 639-5 or some other thing (source: Wikipedia). But, `languageCode` is
					// documented as ISO 639-2. Changing the definition would be a breaking change. This will get
					// cleaned up in the future by defining languageCode to be BCP 47 instead.
					this.currentTrack.languageCode = languageSubtag;
				} else {
					this.currentTrack.languageCode = UNDETERMINED_LANGUAGE;
				}

				this.currentTrack.hasLanguageBcp47 = true;
			}; break;

			case EBMLId.Video: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.readContiguousElements(slice.slice(dataStartPos, size));
			}; break;

			case EBMLId.PixelWidth: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.currentTrack.info.width = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.PixelHeight: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.currentTrack.info.height = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.DisplayWidth: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.currentTrack.info.displayWidth = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.DisplayHeight: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.currentTrack.info.displayHeight = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.DisplayUnit: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.currentTrack.info.displayUnit = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.StereoMode: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.currentTrack.info.stereoMode = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.AlphaMode: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.currentTrack.info.alphaMode = readUnsignedInt(slice, size) === 1;
			}; break;

			case EBMLId.Colour: {
				if (this.currentTrack?.info?.type !== 'video') break;

				this.readContiguousElements(slice.slice(dataStartPos, size));
			}; break;

			case EBMLId.MatrixCoefficients: {
				if (this.currentTrack?.info?.type !== 'video') break;

				const matrixCoefficients = size === 0 ? 2 : readUnsignedInt(slice, size);
				const mapped = MATRIX_COEFFICIENTS_MAP_INVERSE[matrixCoefficients];
				this.currentTrack.info.colorSpace.matrix = mapped as VideoColorSpaceInit['matrix'];
			}; break;

			case EBMLId.Range: {
				if (this.currentTrack?.info?.type !== 'video') break;

				const range = readUnsignedInt(slice, size);
				this.currentTrack.info.colorSpace.fullRange = range === 1 || range === 2
					? range === 2
					: undefined;
			}; break;

			case EBMLId.TransferCharacteristics: {
				if (this.currentTrack?.info?.type !== 'video') break;

				const transferCharacteristics = size === 0 ? 2 : readUnsignedInt(slice, size);
				const mapped = TRANSFER_CHARACTERISTICS_MAP_INVERSE[transferCharacteristics];
				this.currentTrack.info.colorSpace.transfer = mapped as VideoColorSpaceInit['transfer'];
			}; break;

			case EBMLId.Primaries: {
				if (this.currentTrack?.info?.type !== 'video') break;

				const primaries = size === 0 ? 2 : readUnsignedInt(slice, size);
				const mapped = COLOR_PRIMARIES_MAP_INVERSE[primaries];
				this.currentTrack.info.colorSpace.primaries = mapped as VideoColorSpaceInit['primaries'];
			}; break;

			case EBMLId.Projection: {
				if (this.currentTrack?.info?.type !== 'video') break;

				const info = this.currentTrack.info;
				const projection = {
					type: 0, // Rectangular
					yaw: 0,
					pitch: 0,
					roll: 0,
				};

				this.currentProjection = projection;
				this.readContiguousElements(slice.slice(dataStartPos, size));
				this.currentProjection = null;

				if (projection.type !== 0) break;

				// Yaw and pitch rotate the frame in 3D space about the vertical and horizontal axis respectively. When
				// snapped to multiples of 90 degrees, that amounts to scaling each axis by the cosine, which models
				// flips.
				const angleToScale = (angle: number) => {
					try {
						return Math.round(Math.cos(normalizeRotation(angle) * DEG_TO_RAD));
					} catch {
						return 1; // It wasn't a valid rotation
					}
				};

				info.horizontalScale = angleToScale(projection.yaw);
				info.verticalScale = angleToScale(projection.pitch);

				try {
					info.rotation = normalizeRotation(-projection.roll); // Convert counter-clockwise to clockwise
				} catch {
					// It wasn't a valid rotation
				}
			}; break;

			case EBMLId.ProjectionType: {
				if (!this.currentProjection) break;

				this.currentProjection.type = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.ProjectionPoseYaw: {
				if (!this.currentProjection) break;

				this.currentProjection.yaw = readFloat(slice, size);
			}; break;

			case EBMLId.ProjectionPosePitch: {
				if (!this.currentProjection) break;

				this.currentProjection.pitch = readFloat(slice, size);
			}; break;

			case EBMLId.ProjectionPoseRoll: {
				if (!this.currentProjection) break;

				this.currentProjection.roll = readFloat(slice, size);
			}; break;

			case EBMLId.Audio: {
				if (this.currentTrack?.info?.type !== 'audio') break;

				this.readContiguousElements(slice.slice(dataStartPos, size));
			}; break;

			case EBMLId.SamplingFrequency: {
				if (this.currentTrack?.info?.type !== 'audio') break;

				const sampleRate = size === 0 ? 8000 : readFloat(slice, size);
				if (!(sampleRate > 0) || !Number.isFinite(sampleRate)) {
					throw new Error('Invalid SamplingFrequency element: must be a positive, finite number.');
				}

				this.currentTrack.info.sampleRate = sampleRate;
			}; break;

			case EBMLId.OutputSamplingFrequency: {
				if (this.currentTrack?.info?.type !== 'audio') break;

				const outputSampleRate = readFloat(slice, size);
				if (!(outputSampleRate > 0) || !Number.isFinite(outputSampleRate)) {
					throw new Error('Invalid OutputSamplingFrequency element: must be a positive, finite number.');
				}

				this.currentTrack.info.outputSampleRate = outputSampleRate;
			}; break;

			case EBMLId.Channels: {
				if (this.currentTrack?.info?.type !== 'audio') break;

				const numberOfChannels = size === 0 ? 1 : readUnsignedInt(slice, size);
				if (numberOfChannels === 0) {
					throw new Error('Invalid Channels element: must not be 0.');
				}

				this.currentTrack.info.numberOfChannels = numberOfChannels;
			}; break;

			case EBMLId.BitDepth: {
				if (this.currentTrack?.info?.type !== 'audio') break;

				this.currentTrack.info.bitDepth = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.CuePoint: {
				if (!this.currentSegment) break;

				this.readContiguousElements(slice.slice(dataStartPos, size));
				this.currentCueTime = null;
			}; break;

			case EBMLId.CueTime: {
				this.currentCueTime = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.CueTrackPositions: {
				if (this.currentCueTime === null || !this.currentSegment) break;

				const cuePoint: CuePoint = { time: this.currentCueTime, trackId: -1, clusterPosition: -1 };
				this.currentSegment.cuePoints.push(cuePoint);
				this.readContiguousElements(slice.slice(dataStartPos, size));

				if (cuePoint.trackId === -1 || cuePoint.clusterPosition === -1) {
					this.currentSegment.cuePoints.pop();
				}
			}; break;

			case EBMLId.CueTrack: {
				const lastCuePoint = this.currentSegment?.cuePoints[this.currentSegment.cuePoints.length - 1];
				if (!lastCuePoint) break;

				lastCuePoint.trackId = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.CueClusterPosition: {
				const lastCuePoint = this.currentSegment?.cuePoints[this.currentSegment.cuePoints.length - 1];
				if (!lastCuePoint) break;

				assert(this.currentSegment);
				lastCuePoint.clusterPosition = this.currentSegment.dataStartPos + readUnsignedInt(slice, size);
			}; break;

			case EBMLId.Timestamp: {
				if (!this.currentCluster) break;

				this.currentCluster.timestamp = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.SimpleBlock: {
				if (!this.currentCluster) break;

				const blockSlice = slice.slice(dataStartPos, size);

				const trackNumber = readVarInt(blockSlice);
				if (trackNumber === null || blockSlice.remainingLength < 3) break;

				const trackData = this.getTrackDataInCluster(this.currentCluster, trackNumber);
				if (!trackData) break; // Not a track we care about

				const relativeTimestamp = readI16Be(blockSlice);

				const flags = readU8(blockSlice);
				const lacing = (flags >> 1) & 0x3 as BlockLacing; // If the block is laced, we'll expand it later

				const isKeyFrame = !!(flags & 0x80);
				const blockData = readBytes(blockSlice, blockSlice.remainingLength);
				const hasDecodingInstructions = trackData.track.decodingInstructions.length > 0;

				trackData.blocks.push({
					timestamp: relativeTimestamp, // We'll add the cluster's timestamp to this later
					duration: 0, // Will set later
					isKeyFrame,
					data: blockData,
					lacing,
					decoded: !hasDecodingInstructions,
					postProcessed: false,
					mainAdditional: null,
				});
			}; break;

			case EBMLId.BlockGroup: {
				if (!this.currentCluster) break;

				this.readContiguousElements(slice.slice(dataStartPos, size));

				this.currentBlock = null;
			}; break;

			case EBMLId.Block: {
				if (!this.currentCluster) break;

				const blockSlice = slice.slice(dataStartPos, size);

				const trackNumber = readVarInt(blockSlice);
				if (trackNumber === null || blockSlice.remainingLength < 3) break;

				const trackData = this.getTrackDataInCluster(this.currentCluster, trackNumber);
				if (!trackData) break;

				const relativeTimestamp = readI16Be(blockSlice);

				const flags = readU8(blockSlice);
				const lacing = (flags >> 1) & 0x3 as BlockLacing; // If the block is laced, we'll expand it later

				const blockData = readBytes(blockSlice, blockSlice.remainingLength);
				const hasDecodingInstructions = trackData.track.decodingInstructions.length > 0;

				this.currentBlock = {
					timestamp: relativeTimestamp, // We'll add the cluster's timestamp to this later
					duration: 0, // Will set later
					isKeyFrame: true,
					data: blockData,
					lacing,
					decoded: !hasDecodingInstructions,
					postProcessed: false,
					mainAdditional: null,
				};
				trackData.blocks.push(this.currentBlock);
			}; break;

			case EBMLId.BlockAdditions: {
				this.readContiguousElements(slice.slice(dataStartPos, size));
			}; break;

			case EBMLId.BlockMore: {
				// Nested elements may modify the current block, so hold onto it
				const block = this.currentBlock;
				if (!block) break;

				const blockAdditional = {
					addId: 1,
					data: null as Uint8Array | null,
				};
				this.currentBlockAdditional = blockAdditional;

				this.readContiguousElements(slice.slice(dataStartPos, size));

				if (blockAdditional.data && blockAdditional.addId === 1) {
					block.mainAdditional = blockAdditional.data;
				}
				this.currentBlockAdditional = null;
			}; break;

			case EBMLId.BlockAdditional: {
				if (!this.currentBlockAdditional) break;

				this.currentBlockAdditional.data = readBytes(slice, size);
			}; break;

			case EBMLId.BlockAddID: {
				if (!this.currentBlockAdditional) break;

				this.currentBlockAdditional.addId = size === 0 ? 1 : readUnsignedInt(slice, size);
			}; break;

			case EBMLId.BlockDuration: {
				if (!this.currentBlock) break;

				this.currentBlock.duration = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.ReferenceBlock: {
				if (!this.currentBlock) break;

				this.currentBlock.isKeyFrame = false;
				// We ignore the actual value here, we just use the reference as an indicator for "not a key frame".
				// This is in line with FFmpeg's behavior.
			}; break;

			case EBMLId.Tag: {
				this.currentTagTargetIsMovie = true;
				this.readContiguousElements(slice.slice(dataStartPos, size));
			}; break;

			case EBMLId.Targets: {
				this.readContiguousElements(slice.slice(dataStartPos, size));
			}; break;

			case EBMLId.TargetTypeValue: {
				const targetTypeValue = size === 0 ? 50 : readUnsignedInt(slice, size);
				if (targetTypeValue !== 50) {
					this.currentTagTargetIsMovie = false;
				}
			}; break;

			case EBMLId.TagTrackUID:
			case EBMLId.TagEditionUID:
			case EBMLId.TagChapterUID:
			case EBMLId.TagAttachmentUID: {
				this.currentTagTargetIsMovie = false;
			}; break;

			case EBMLId.SimpleTag: {
				if (!this.currentTagTargetIsMovie) break;

				this.currentSimpleTagName = null;
				this.readContiguousElements(slice.slice(dataStartPos, size));
			}; break;

			case EBMLId.TagName: {
				this.currentSimpleTagName = readUnicodeString(slice, size);
			}; break;

			case EBMLId.TagString: {
				if (!this.currentSimpleTagName) break;

				const value = readUnicodeString(slice, size);
				this.processTagValue(this.currentSimpleTagName, value);
			}; break;

			case EBMLId.TagBinary: {
				if (!this.currentSimpleTagName) break;

				const value = readBytes(slice, size);
				this.processTagValue(this.currentSimpleTagName, value);
			}; break;

			case EBMLId.AttachedFile: {
				if (!this.currentSegment || this.currentAttachedFile) break; // Nested attached files make no sense

				this.currentAttachedFile = {
					fileUid: null,
					fileName: null,
					fileMediaType: null,
					fileData: null,
					fileDescription: null,
				};

				this.readContiguousElements(slice.slice(dataStartPos, size));

				const tags = this.currentSegment.metadataTags;

				if (this.currentAttachedFile.fileUid && this.currentAttachedFile.fileData) {
					// All attached files get surfaced in the `raw` metadata tags
					tags.raw ??= {};
					tags.raw[this.currentAttachedFile.fileUid.toString()] = new AttachedFile(
						this.currentAttachedFile.fileData,
						this.currentAttachedFile.fileMediaType ?? undefined,
						this.currentAttachedFile.fileName ?? undefined,
						this.currentAttachedFile.fileDescription ?? undefined,
					);
				}

				// Only process image attachments
				if (this.currentAttachedFile.fileMediaType?.startsWith('image/') && this.currentAttachedFile.fileData) {
					const fileName = this.currentAttachedFile.fileName;
					let kind: 'coverFront' | 'coverBack' | 'unknown' = 'unknown';

					if (fileName) {
						const lowerName = fileName.toLowerCase();
						if (lowerName.startsWith('cover.')) {
							kind = 'coverFront';
						} else if (lowerName.startsWith('back.')) {
							kind = 'coverBack';
						}
					}

					tags.images ??= [];
					tags.images.push({
						data: this.currentAttachedFile.fileData,
						mimeType: this.currentAttachedFile.fileMediaType,
						kind,
						name: this.currentAttachedFile.fileName ?? undefined,
						description: this.currentAttachedFile.fileDescription ?? undefined,
					});
				}

				this.currentAttachedFile = null;
			}; break;

			case EBMLId.FileUID: {
				if (!this.currentAttachedFile) break;

				this.currentAttachedFile.fileUid = readUnsignedBigInt(slice, size);
			}; break;

			case EBMLId.FileName: {
				if (!this.currentAttachedFile) break;

				this.currentAttachedFile.fileName = readUnicodeString(slice, size);
			}; break;

			case EBMLId.FileMediaType: {
				if (!this.currentAttachedFile) break;

				this.currentAttachedFile.fileMediaType = readAsciiString(slice, size);
			}; break;

			case EBMLId.FileData: {
				if (!this.currentAttachedFile) break;

				this.currentAttachedFile.fileData = readBytes(slice, size);
			}; break;

			case EBMLId.FileDescription: {
				if (!this.currentAttachedFile) break;

				this.currentAttachedFile.fileDescription = readUnicodeString(slice, size);
			}; break;

			case EBMLId.ContentEncodings: {
				// Nested elements may modify the current track, so hold onto it
				const track = this.currentTrack;
				if (!track) break;

				this.readContiguousElements(slice.slice(dataStartPos, size));

				// "**MUST** start with the `ContentEncoding` with the highest `ContentEncodingOrder`"
				track.decodingInstructions.sort((a, b) => b.order - a.order);
			}; break;

			case EBMLId.ContentEncoding: {
				const track = this.currentTrack;
				if (!track) break;

				const instruction: DecodingInstruction = {
					order: 0,
					scope: ContentEncodingScope.Block,
					data: null,
				};
				this.currentDecodingInstruction = instruction;

				this.readContiguousElements(slice.slice(dataStartPos, size));

				if (instruction.data) {
					track.decodingInstructions.push(instruction);
				}

				this.currentDecodingInstruction = null;
			}; break;

			case EBMLId.ContentEncodingOrder: {
				if (!this.currentDecodingInstruction) break;

				this.currentDecodingInstruction.order = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.ContentEncodingScope: {
				if (!this.currentDecodingInstruction) break;

				this.currentDecodingInstruction.scope = size === 0
					? ContentEncodingScope.Block
					: readUnsignedInt(slice, size);
			}; break;

			case EBMLId.ContentCompression: {
				if (!this.currentDecodingInstruction) break;

				this.currentDecodingInstruction.data = {
					type: 'decompress',
					algorithm: ContentCompAlgo.Zlib,
					settings: null,
				};

				this.readContiguousElements(slice.slice(dataStartPos, size));
			}; break;

			case EBMLId.ContentCompAlgo: {
				if (this.currentDecodingInstruction?.data?.type !== 'decompress') break;

				this.currentDecodingInstruction.data.algorithm = readUnsignedInt(slice, size);
			}; break;

			case EBMLId.ContentCompSettings: {
				if (this.currentDecodingInstruction?.data?.type !== 'decompress') break;

				this.currentDecodingInstruction.data.settings = readBytes(slice, size);
			}; break;

			case EBMLId.ContentEncryption: {
				if (!this.currentDecodingInstruction) break;

				this.currentDecodingInstruction.data = {
					type: 'decrypt',
				};
			}; break;
		}

		slice.filePos = dataStartPos + size;
		return true;
	}

	decodeBlockData(track: InternalTrack, rawData: Uint8Array) {
		assert(track.decodingInstructions.length > 0); // This method shouldn't be called otherwise

		let currentData = rawData;

		for (const instruction of track.decodingInstructions) {
			assert(instruction.data);

			switch (instruction.data.type) {
				case 'decompress': {
					switch (instruction.data.algorithm) {
						case ContentCompAlgo.HeaderStripping: {
							if (instruction.data.settings && instruction.data.settings.length > 0) {
								const prefix = instruction.data.settings;
								const newData = new Uint8Array(prefix.length + currentData.length);

								newData.set(prefix, 0);
								newData.set(currentData, prefix.length);

								currentData = newData;
							}
						}; break;

						default: {
							// Unhandled
						};
					}
				}; break;

				default: {
					// Unhandled
				};
			}
		}

		return currentData;
	}

	processTagValue(name: string, value: string | Uint8Array) {
		if (!this.currentSegment?.metadataTags) return;

		const metadataTags = this.currentSegment.metadataTags;
		metadataTags.raw ??= {};
		metadataTags.raw[name] ??= value;

		if (typeof value === 'string') {
			switch (name.toLowerCase()) {
				case 'title': {
					metadataTags.title ??= value;
				}; break;

				case 'description': {
					metadataTags.description ??= value;
				}; break;

				case 'artist': {
					metadataTags.artist ??= value;
				}; break;

				case 'album': {
					metadataTags.album ??= value;
				}; break;

				case 'album_artist': {
					metadataTags.albumArtist ??= value;
				}; break;

				case 'genre': {
					metadataTags.genre ??= value;
				}; break;

				case 'bpm': {
					const bpm = Number.parseInt(value, 10);
					if (Number.isInteger(bpm) && bpm > 0) {
						metadataTags.beatsPerMinute ??= bpm;
					}
				}; break;

				case 'comment': {
					metadataTags.comment ??= value;
				}; break;

				case 'lyrics': {
					metadataTags.lyrics ??= value;
				}; break;

				case 'date': {
					const date = parseIsoSuffix(value);
					if (date) {
						metadataTags.date ??= date;
					}
				}; break;

				case 'track_number':
				case 'part_number': {
					const parts = value.split('/');
					const trackNum = Number.parseInt(parts[0]!, 10);
					const tracksTotal = parts[1] && Number.parseInt(parts[1], 10);

					if (Number.isInteger(trackNum) && trackNum > 0) {
						metadataTags.trackNumber ??= trackNum;
					}
					if (tracksTotal && Number.isInteger(tracksTotal) && tracksTotal > 0) {
						metadataTags.tracksTotal ??= tracksTotal;
					}
				}; break;

				case 'disc_number':
				case 'disc': {
					const discParts = value.split('/');
					const discNum = Number.parseInt(discParts[0]!, 10);
					const discsTotal = discParts[1] && Number.parseInt(discParts[1], 10);

					if (Number.isInteger(discNum) && discNum > 0) {
						metadataTags.discNumber ??= discNum;
					}
					if (discsTotal && Number.isInteger(discsTotal) && discsTotal > 0) {
						metadataTags.discsTotal ??= discsTotal;
					}
				}; break;
			}
		}
	}

	getDurationFromMetadata(segment: Segment) {
		if (segment.duration <= 0) {
			return null;
		}

		const minCodecDelay = Math.min(...segment.tracks.map(x => x.codecDelay));

		// We treat the Duration field as the end timestamp of the segment, since this is what FFmpeg treats it as.
		// The spec unfortunately does not clarify what it means by duration here.
		return (segment.duration - minCodecDelay) / segment.timestampFactor;
	}
}

abstract class MatroskaTrackBacking implements InputTrackBacking {
	packetToClusterLocation = new WeakMap<EncodedPacket, {
		cluster: Cluster;
		blockIndex: number;
	}>();

	constructor(public internalTrack: InternalTrack) {}

	abstract getType(): TrackType;
	abstract getDecoderConfig(): Promise<VideoDecoderConfig | AudioDecoderConfig | null>;

	getNumber() {
		const demuxer = this.internalTrack.demuxer;
		const trackType = this.internalTrack.trackBacking!.getType();
		let number = 0;

		for (const segment of demuxer.segments) {
			for (const track of segment.tracks) {
				if (track.trackBacking!.getType() === trackType) {
					number++;
				}

				if (track === this.internalTrack) {
					return number;
				}
			}
		}

		assert(false);
	}

	getCodec(): MediaCodec | null {
		throw new Error('Not implemented on base class.');
	}

	getInternalCodecId() {
		return this.internalTrack.codecId;
	}

	getName() {
		return this.internalTrack.name;
	}

	getLanguageCode() {
		return this.internalTrack.languageCode;
	}

	getTimeResolution() {
		return this.internalTrack.segment.timestampFactor;
	}

	isRelativeToUnixEpoch() {
		return false;
	}

	getUnixTimeForTimestamp() {
		return null;
	}

	getDisposition() {
		return this.internalTrack.disposition;
	}

	getPairingMask() {
		return 1n;
	}

	getBitrate() {
		return null;
	}

	getAverageBitrate() {
		return null;
	}

	async getDurationFromMetadata() {
		return this.internalTrack.demuxer.getDurationFromMetadata(this.internalTrack.segment);
	}

	async getLiveRefreshInterval() {
		return null;
	}

	async getFirstPacket(options: PacketRetrievalOptions) {
		return this.performClusterLookup(
			null,
			(cluster) => {
				const trackData = cluster.trackData.get(this.internalTrack.id);
				if (trackData) {
					return {
						blockIndex: 0,
						correctBlockFound: true,
					};
				}

				return {
					blockIndex: -1,
					correctBlockFound: false,
				};
			},
			-Infinity, // Use -Infinity as a search timestamp to avoid using the cues
			Infinity,
			options,
		);
	}

	private intoTimescale(timestamp: number) {
		// Do a little rounding to catch cases where the result is very close to an integer. If it is, it's likely
		// that the number was originally an integer divided by the timescale. For stability, it's best
		// to return the integer in this case.
		return roundIfAlmostInteger(timestamp * this.internalTrack.segment.timestampFactor)
			+ this.internalTrack.codecDelay;
	}

	async getPacket(timestamp: number, options: PacketRetrievalOptions) {
		const timestampInTimescale = this.intoTimescale(timestamp);

		return this.performClusterLookup(
			null,
			(cluster) => {
				const trackData = cluster.trackData.get(this.internalTrack.id);
				if (!trackData) {
					return { blockIndex: -1, correctBlockFound: false };
				}

				const index = binarySearchLessOrEqual(
					trackData.presentationTimestamps,
					timestampInTimescale,
					x => x.timestamp,
				);

				const blockIndex = index !== -1 ? trackData.presentationTimestamps[index]!.blockIndex : -1;
				const correctBlockFound = index !== -1 && timestampInTimescale < trackData.endTimestamp;

				return { blockIndex, correctBlockFound };
			},
			timestampInTimescale,
			timestampInTimescale,
			options,
		);
	}

	async getNextPacket(packet: EncodedPacket, options: PacketRetrievalOptions) {
		const locationInCluster = this.packetToClusterLocation.get(packet);
		if (locationInCluster === undefined) {
			throw new Error('Packet was not created from this track.');
		}

		return this.performClusterLookup(
			locationInCluster.cluster,
			(cluster) => {
				if (cluster === locationInCluster.cluster) {
					const trackData = cluster.trackData.get(this.internalTrack.id)!;
					if (locationInCluster.blockIndex + 1 < trackData.blocks.length) {
						// We can simply take the next block in the cluster
						return {
							blockIndex: locationInCluster.blockIndex + 1,
							correctBlockFound: true,
						};
					}
				} else {
					const trackData = cluster.trackData.get(this.internalTrack.id);
					if (trackData) {
						return {
							blockIndex: 0,
							correctBlockFound: true,
						};
					}
				}

				return {
					blockIndex: -1,
					correctBlockFound: false,
				};
			},
			-Infinity, // Use -Infinity as a search timestamp to avoid using the cues
			Infinity,
			options,
		);
	}

	async getKeyPacket(timestamp: number, options: PacketRetrievalOptions) {
		const timestampInTimescale = this.intoTimescale(timestamp);

		return this.performClusterLookup(
			null,
			(cluster) => {
				const trackData = cluster.trackData.get(this.internalTrack.id);
				if (!trackData) {
					return { blockIndex: -1, correctBlockFound: false };
				}

				const index = findLastIndex(trackData.presentationTimestamps, (x) => {
					const block = trackData.blocks[x.blockIndex]!;
					return block.isKeyFrame && x.timestamp <= timestampInTimescale;
				});

				const blockIndex = index !== -1 ? trackData.presentationTimestamps[index]!.blockIndex : -1;
				const correctBlockFound = index !== -1 && timestampInTimescale < trackData.endTimestamp;

				return { blockIndex, correctBlockFound };
			},
			timestampInTimescale,
			timestampInTimescale,
			options,
			true,
		);
	}

	async getNextKeyPacket(packet: EncodedPacket, options: PacketRetrievalOptions) {
		const locationInCluster = this.packetToClusterLocation.get(packet);
		if (locationInCluster === undefined) {
			throw new Error('Packet was not created from this track.');
		}

		return this.performClusterLookup(
			locationInCluster.cluster,
			(cluster) => {
				if (cluster === locationInCluster.cluster) {
					const trackData = cluster.trackData.get(this.internalTrack.id)!;

					for (let i = locationInCluster.blockIndex + 1; i < trackData.blocks.length; i++) {
						if (trackData.blocks[i]!.isKeyFrame) {
							// We can simply take the next key frame in the cluster
							return {
								blockIndex: i,
								correctBlockFound: true,
							};
						}
					}
				} else {
					const trackData = cluster.trackData.get(this.internalTrack.id);
					if (trackData && trackData.firstKeyFrameTimestamp !== null) {
						const keyFrameIndex = trackData.blocks.findIndex(x => x.isKeyFrame);
						assert(keyFrameIndex !== -1); // There must be one

						return {
							blockIndex: keyFrameIndex,
							correctBlockFound: true,
						};
					}
				}

				return {
					blockIndex: -1,
					correctBlockFound: false,
				};
			},
			-Infinity, // Use -Infinity as a search timestamp to avoid using the cues
			Infinity,
			options,
		);
	}

	private async fetchPacketInCluster(cluster: Cluster, blockIndex: number, options: PacketRetrievalOptions) {
		if (blockIndex === -1) {
			return null;
		}

		const trackData = cluster.trackData.get(this.internalTrack.id)!;
		const block = trackData.blocks[blockIndex];
		assert(block);

		// Perform lazy decoding if needed
		if (!block.decoded) {
			block.data = this.internalTrack.demuxer.decodeBlockData(this.internalTrack, block.data);
			block.decoded = true;
		}

		if (!block.postProcessed) {
			if (this.internalTrack.info?.codec === 'prores') {
				// For some reason, ProRes packets are stored in Matroska without the frame container atom. FFmpeg cites
				// the "Matroska spec" but the actual spec says nothing about this.

				const hasFrameContainer = block.data.length >= 8
					&& block.data[4] === 105 // 'i'
					&& block.data[5] === 99 // 'c'
					&& block.data[6] === 112 // 'p'
					&& block.data[7] === 102; // 'f'

				if (!hasFrameContainer) {
					// Wrap the frame in a frame container
					const newData = new Uint8Array(block.data.length + 8);
					const newDataView = toDataView(newData);

					newDataView.setUint32(0, newData.length, false);
					newData[4] = 105; // 'i'
					newData[5] = 99; // 'c'
					newData[6] = 112; // 'p'
					newData[7] = 102; // 'f'
					newData.set(block.data, 8);
					block.data = newData;
				}
			}

			block.postProcessed = true;
		}

		const data = options.metadataOnly ? PLACEHOLDER_DATA : block.data;

		const { codecDelay, segment } = this.internalTrack;
		const timestamp = (block.timestamp - codecDelay) / segment.timestampFactor;
		const duration = block.duration / segment.timestampFactor;

		const sideData: EncodedPacketSideData = {};
		if (block.mainAdditional && this.internalTrack.info?.type === 'video' && this.internalTrack.info.alphaMode) {
			sideData.alpha = options.metadataOnly ? PLACEHOLDER_DATA : block.mainAdditional;
			sideData.alphaByteLength = block.mainAdditional.byteLength;
		}

		const packet = new EncodedPacket(
			data,
			block.isKeyFrame ? 'key' : 'delta',
			timestamp,
			duration,
			cluster.dataStartPos + blockIndex,
			block.data.byteLength,
			sideData,
		);

		this.packetToClusterLocation.set(packet, { cluster, blockIndex });

		return packet;
	}

	/** Looks for a packet in the clusters while trying to load as few clusters as possible to retrieve it. */
	private async performClusterLookup(
		// The cluster where we start looking
		startCluster: Cluster | null,
		// This function returns the best-matching block in a given cluster
		getMatchInCluster: (cluster: Cluster) => { blockIndex: number; correctBlockFound: boolean },
		// The timestamp with which we can search the lookup table
		searchTimestamp: number,
		// The timestamp for which we know the correct block will not come after it
		latestTimestamp: number,
		options: PacketRetrievalOptions,
		// Whether the match must be a key frame, so that position cache entries without one can be skipped
		requireKeyFrame = false,
	): Promise<EncodedPacket | null> {
		const { demuxer, segment, cuePoints, clusterPositionCache } = this.internalTrack;

		let bestCluster: Cluster | null = null;
		let bestBlockIndex = -1;

		if (startCluster) {
			const { blockIndex, correctBlockFound } = getMatchInCluster(startCluster);

			if (correctBlockFound) {
				return this.fetchPacketInCluster(startCluster, blockIndex, options);
			}

			if (blockIndex !== -1) {
				bestCluster = startCluster;
				bestBlockIndex = blockIndex;
			}
		}

		// Search for a cue point; this way, we won't need to start searching from the start of the file
		// but can jump right into the correct cluster (or at least nearby).
		let cuePointIndex = binarySearchLessOrEqual(cuePoints, searchTimestamp, x => x.time);
		// Also check the position cache. Clusters read during the lookup land after this index, so it stays valid.
		let positionCacheIndex = binarySearchLessOrEqual(clusterPositionCache, searchTimestamp, x => x.startTimestamp);

		// The position for which we know the correct block will not come after it
		let stopPos = Infinity;

		while (true) {
			// Skip lookup entries pointing into clusters we've already scanned
			while (cuePointIndex !== -1 && cuePoints[cuePointIndex]!.clusterPosition >= stopPos) {
				cuePointIndex--;
			}
			while (
				positionCacheIndex !== -1
				&& (
					clusterPositionCache[positionCacheIndex]!.elementStartPos >= stopPos
					|| (requireKeyFrame && !clusterPositionCache[positionCacheIndex]!.hasKeyFrame)
				)
			) {
				positionCacheIndex--;
			}

			const lookupEntryPosition = Math.max(
				cuePoints[cuePointIndex]?.clusterPosition ?? 0,
				clusterPositionCache[positionCacheIndex]?.elementStartPos ?? 0,
			) || null;

			let currentPos: number;
			let currentCluster: Cluster | null = null;

			if (!startCluster) {
				currentPos = lookupEntryPosition ?? segment.clusterSeekStartPos;
			} else {
				if (lookupEntryPosition === null || startCluster.elementStartPos >= lookupEntryPosition) {
					currentPos = startCluster.elementEndPos;
					currentCluster = startCluster;
				} else {
					// Use the lookup entry
					currentPos = lookupEntryPosition;
				}
			}

			const scanStartPos = currentCluster ? currentCluster.elementStartPos : currentPos;

			while (
				(segment.elementEndPos === null || currentPos <= segment.elementEndPos - MIN_HEADER_SIZE)
				&& currentPos < stopPos
			) {
				if (currentCluster) {
					const trackData = currentCluster.trackData.get(this.internalTrack.id);
					if (trackData && trackData.startTimestamp > latestTimestamp) {
						// We're already past the upper bound, no need to keep searching
						break;
					}

					currentCluster = null; // So we don't process it again next iteration
				}

				const summary = segment.clusterSummaries.get(currentPos);
				if (summary && !summary.trackIds.has(this.internalTrack.id)) {
					// We've read this cluster before and know it has nothing for this track, so let's not read it again
					currentPos = summary.elementEndPos;
					continue;
				}

				// Load the header
				let slice = demuxer.reader.requestSliceRange(currentPos, MIN_HEADER_SIZE, MAX_HEADER_SIZE);
				if (isThenable(slice)) slice = await slice;
				if (!slice) break;

				const elementStartPos = currentPos;
				const elementHeader = readElementHeader(slice);

				if (segment.elementEndPos === null && elementHeader && LEVEL_0_EBML_IDS.includes(elementHeader.id)) {
					// A new file or segment begins here, so we now know where this segment ends. The new segment is
					// just ignored, since we're likely in a livestreamed file and thus only care about the first
					// segment.
					segment.elementEndPos = elementStartPos;
					break;
				}

				if (
					!elementHeader
					|| (!LEVEL_1_EBML_IDS.includes(elementHeader.id) && elementHeader.id !== EBMLId.Void)
				) {
					// There's an element here that shouldn't be here. Might be garbage. In this case, let's
					// try and resync to the next valid element.
					const nextPos = await resync(
						demuxer.reader,
						elementStartPos + 1,
						LEVEL_1_EBML_IDS,
						Math.min(segment.elementEndPos ?? Infinity, elementStartPos + MAX_RESYNC_LENGTH),
					);

					if (nextPos) {
						currentPos = nextPos;
						continue;
					} else {
						break; // Resync failed
					}
				}

				const id = elementHeader.id;
				let size = elementHeader.size;
				const dataStartPos = slice.filePos;

				if (id === EBMLId.Cluster) {
					currentCluster = await demuxer.readCluster(elementStartPos, segment);
					// readCluster computes the proper size even if it's undefined in the header, so let's use that
					// instead
					size = currentCluster.elementEndPos - dataStartPos;

					const { blockIndex, correctBlockFound } = getMatchInCluster(currentCluster);
					if (correctBlockFound) {
						return this.fetchPacketInCluster(currentCluster, blockIndex, options);
					}

					if (blockIndex !== -1) {
						bestCluster = currentCluster;
						bestBlockIndex = blockIndex;
					}
				}

				if (size === undefined) {
					// Undefined element size (can happen in livestreamed files). In this case, we need to do some
					// searching to determine the actual size of the element.

					assert(id !== EBMLId.Cluster); // Undefined cluster sizes are fixed further up

					// Search for the next element at level 0 or 1
					const nextElementPos = await searchForNextElementId(
						demuxer.reader,
						dataStartPos,
						LEVEL_0_AND_1_EBML_IDS,
						segment.elementEndPos,
					);

					size = nextElementPos.pos - dataStartPos;
				}

				currentPos = dataStartPos + size;
			}

			if (lookupEntryPosition === null || (bestCluster && bestCluster.elementStartPos >= lookupEntryPosition)) {
				break;
			}

			// We found a lookup entry but no cluster from there on that satisfied the match. In this case, let's search
			// again from the lookup entry preceding the clusters we just scanned.
			//
			// Note that this doesn't only kick for faulty cue points but also for multi-track files where only one
			// track has cue points. Since we distribute the cue points to the track with none, they might not
			// accurately reflect where media can be found.
			stopPos = scanStartPos; // So we don't read the same clusters again
			startCluster = null;
		}

		if (bestCluster) {
			// If we finished looping but didn't find a perfect match, still return the best match we found
			return this.fetchPacketInCluster(bestCluster, bestBlockIndex, options);
		}

		return null;
	}
}

class MatroskaVideoTrackBacking extends MatroskaTrackBacking implements InputVideoTrackBacking {
	declare internalTrack: InternalVideoTrack;
	decoderConfigPromise: Promise<VideoDecoderConfig> | null = null;

	constructor(internalTrack: InternalVideoTrack) {
		super(internalTrack);
	}

	getType() {
		return 'video' as const;
	}

	override getCodec(): VideoCodec | null {
		return this.internalTrack.info.codec;
	}

	getCodedWidth() {
		return this.internalTrack.info.width;
	}

	getCodedHeight() {
		return this.internalTrack.info.height;
	}

	getSquarePixelWidth() {
		return this.internalTrack.info.squarePixelWidth;
	}

	getSquarePixelHeight() {
		return this.internalTrack.info.squarePixelHeight;
	}

	getTransformationMatrix() {
		const info = this.internalTrack.info;

		// Yaw and pitch are applied before roll
		const linear = multiplyMatrices(
			scaleMatrix(info.horizontalScale, info.verticalScale),
			rotationMatrix(info.rotation),
		);

		return centeredTransformationMatrix(linear, info.width, info.height);
	}

	async getColorSpace(): Promise<VideoColorSpaceInit> {
		const decoderConfig = await this.getDecoderConfig();
		if (!decoderConfig) {
			return this.internalTrack.info.colorSpace;
		}

		return {
			primaries: decoderConfig.colorSpace?.primaries,
			transfer: decoderConfig.colorSpace?.transfer,
			matrix: decoderConfig.colorSpace?.matrix,
			fullRange: decoderConfig.colorSpace?.fullRange,
		};
	}

	async canBeTransparent() {
		return this.internalTrack.info.alphaMode || (
			this.internalTrack.info.codec === 'prores' && (
				this.internalTrack.info.proresFormat === 'ap4h'
				|| this.internalTrack.info.proresFormat === 'ap4x'
			)
		);
	}

	async getDecoderConfig(): Promise<VideoDecoderConfig | null> {
		if (!this.internalTrack.info.codec) {
			return null;
		}

		return this.decoderConfigPromise ??= (async (): Promise<VideoDecoderConfig> => {
			const codecPrivate = this.internalTrack.codecPrivate;

			// CodecPrivate holds 4 bytes like those of the AV1CodecConfigurationRecord, optionally followed by OBUs
			// starting with the sequence header. Only that one has all the codec info, including the color.
			let av1CodecInfo = this.internalTrack.info.codec === 'av1' && codecPrivate
				? extractAv1CodecInfoFromPacket(codecPrivate.subarray(4))
				: null;

			let firstPacket: EncodedPacket | null = null;
			const needsPacketForAdditionalInfo
				= this.internalTrack.info.codec === 'vp9'
					|| (this.internalTrack.info.codec === 'av1' && !av1CodecInfo)
					|| this.internalTrack.info.codec === 'prores'
					// Packets are in Annex B format:
					|| (this.internalTrack.info.codec === 'avc' && !this.internalTrack.info.codecDescription)
					// Packets are in Annex B format:
					|| (this.internalTrack.info.codec === 'hevc' && !this.internalTrack.info.codecDescription);

			if (needsPacketForAdditionalInfo) {
				firstPacket = await this.getFirstPacket({});
			}

			if (this.internalTrack.info.codec === 'av1' && firstPacket) {
				av1CodecInfo = extractAv1CodecInfoFromPacket(firstPacket.data);
			}

			const codecInfo = {
				width: this.internalTrack.info.width,
				height: this.internalTrack.info.height,
				codec: this.internalTrack.info.codec,
				codecDescription: this.internalTrack.info.codecDescription,
				colorSpace: this.internalTrack.info.colorSpace,
				avcType: 1 as const, // We don't know better (or do we?) so just assume 'avc1'
				avcCodecInfo: this.internalTrack.info.codec === 'avc' && firstPacket
					? extractAvcDecoderConfigurationRecord(firstPacket.data)
					: null,
				hevcType: 'hev1' as const, // Matroska doesn't promise that parameter sets stay out of the blocks
				hevcCodecInfo: this.internalTrack.info.codec === 'hevc' && firstPacket
					? extractHevcDecoderConfigurationRecord(firstPacket.data)
					: null,
				vp9CodecInfo: this.internalTrack.info.codec === 'vp9' && firstPacket
					? extractVp9CodecInfoFromPacket(firstPacket.data)
					: null,
				av1CodecInfo,
				proresCodecInfo: this.internalTrack.info.codec === 'prores' && firstPacket
					? extractProresCodecInfoFromPacket(firstPacket.data)
					: null,
				proresFormat: this.internalTrack.info.proresFormat,
			};

			if (!colorSpaceIsComplete(this.internalTrack.info.colorSpace)) {
				const colorSpace = extractColorSpace(codecInfo);

				// Fill the missing values
				this.internalTrack.info.colorSpace.primaries ??= colorSpace.primaries;
				this.internalTrack.info.colorSpace.transfer ??= colorSpace.transfer;
				this.internalTrack.info.colorSpace.matrix ??= colorSpace.matrix;
				this.internalTrack.info.colorSpace.fullRange ??= colorSpace.fullRange;
			}

			const config: VideoDecoderConfig = {
				codec: extractVideoCodecString(codecInfo),
				codedWidth: this.internalTrack.info.width,
				codedHeight: this.internalTrack.info.height,
				description: this.internalTrack.info.codecDescription ?? undefined,
				colorSpace: this.internalTrack.info.colorSpace,
			};

			if (
				this.internalTrack.info.width !== this.internalTrack.info.squarePixelWidth
				|| this.internalTrack.info.height !== this.internalTrack.info.squarePixelHeight
			) {
				config.displayAspectWidth = this.internalTrack.info.squarePixelWidth;
				config.displayAspectHeight = this.internalTrack.info.squarePixelHeight;
			}

			return config;
		})();
	}
}

class MatroskaAudioTrackBacking extends MatroskaTrackBacking implements InputAudioTrackBacking {
	declare internalTrack: InternalAudioTrack;
	decoderConfigPromise: Promise<AudioDecoderConfig> | null = null;

	constructor(internalTrack: InternalAudioTrack) {
		super(internalTrack);
	}

	getType() {
		return 'audio' as const;
	}

	override getCodec(): AudioCodec | null {
		return this.internalTrack.info.codec;
	}

	getNumberOfChannels() {
		return this.internalTrack.info.numberOfChannels;
	}

	getSampleRate() {
		return this.internalTrack.info.sampleRate;
	}

	async getDecoderConfig(): Promise<AudioDecoderConfig | null> {
		if (!this.internalTrack.info.codec) {
			return null;
		}

		return this.decoderConfigPromise ??= (async (): Promise<AudioDecoderConfig> => {
			if (this.internalTrack.info.codec === 'dts' && !this.internalTrack.info.dtsFormat) {
				// Gotta check the packet to determine the DTS variant
				const firstPacket = await this.getFirstPacket({});
				this.internalTrack.info.dtsFormat = firstPacket && extractDtsFourCcFromPacket(firstPacket.data);
			}

			return {
				codec: extractAudioCodecString({
					codec: this.internalTrack.info.codec,
					codecDescription: this.internalTrack.info.codecDescription,
					aacCodecInfo: this.internalTrack.info.aacCodecInfo,
					dtsFormat: this.internalTrack.info.dtsFormat,
				}),
				numberOfChannels: this.internalTrack.info.numberOfChannels,
				sampleRate: this.internalTrack.info.sampleRate,
				description: this.internalTrack.info.codecDescription ?? undefined,
			};
		})();
	}
}
